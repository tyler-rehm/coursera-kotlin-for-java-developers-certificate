package board

import board.Direction.*

fun createSquareBoard(width: Int): SquareBoard = TODO()
fun <T> createGameBoard(width: Int): GameBoard<T> = TODO()

